
use my_data;
create table animals(
animal_id varchar(45) primary key,
animal_name varchar(45),
gender varchar(1),
year_of_Arrival int,
number_of_feeds_per_day int

);
alter table animals
change column No_of_feeds_per_day No_of_feeds_per_day int;
insert into 
animals(animal_id, animal_name, gender, year_of_Arrival, No_of_feeds_per_day)
select animal_id, animal_name, gender, year_of_Arrival, No_of_feed_per_day  
from zoo;

alter table animals
change column diet_table diet_table varchar(45);
alter table zoo
add constraint animal_pk_fk
foreign key (animal_id) references animals(animal_id);
alter table zoo
change column animal_id animal_id varchar(45); 
describe animals;
describe zoo;
alter table zoo
change column Diet_id Diet_id text; 

select distinct Keeper_DoB from zoo where Keeper_DoB < 1999;
SELECT COUNT(*) as COUNT, Keeper_DoB
FROM zoo 
GROUP BY Keeper_DoB;

SELECT COUNT(*) AS Female_Count
FROM ZOO
WHERE gender = 'F';

SELECT gender, COUNT(*) AS Count
FROM ZOO
WHERE gender IN ('M', 'F')
GROUP BY gender;

SELECT animal_name, Enclosure_type
FROM ZOO
WHERE Year_of_arrival BETWEEN 2002 AND 2010;

SELECT animal_name, year_of_Arrival, conservation_status
FROM zoo
WHERE conservation_status = 'threatened'
ORDER BY year_of_Arrival DESC
LIMIT 3;

alter table zoo
change column No_of_feeds_per_day No_of_feed_per_day varchar(10);

SELECT animal_id, animal_name, gender, enclosure_type, Year_of_arrival, No_of_feed_per_day
FROM zoo
WHERE gender = 'M'
  AND enclosure_type = 'glass'
  AND Year_of_arrival > 2015;
UPDATE zoo
SET No_of_feed_per_day = No_of_feed_per_day + 1;

alter table keeper
change column Keeper_id Keeper_rank varchar(45);
alter table zoo
change column Keeper_name Keeper_name varchar(45); 
 
insert into 
keeper (Keeper_rank, Keeper_name, Keeper_DoB)
select Keeper_rank, Keeper_name, Keeper_DoB
from zoo;
describe keeper;
describe zoo;

CREATE INDEX idx_keeper_rank ON keeper(Keeper_rank);
ALTER TABLE zoo 
ADD CONSTRAINT keeper_pk_fk 
FOREIGN KEY (Keeper_rank) 
REFERENCES keeper(Keeper_rank);

SELECT * FROM zoo WHERE animal_id NOT IN (SELECT animal_id FROM animals);
DELETE FROM zoo WHERE animal_id NOT IN (SELECT animal_id FROM animals);

-- --

create table diet (
diet_id varchar(45) primary key,
diet_type varchar(45),
diet_price float);

insert into diet (diet_id, diet_type)
select distinct diet_id, diet_type from zoo;

update diet set diet_price = 89 where diet_id = 'D1';
update diet set diet_price = 70 where diet_id = 'D2';
update diet set diet_price = 56 where diet_id = 'D3';

select zoo.*, diet.diet_price 
from zoo
inner join diet 
on zoo.diet_ID = diet.diet_ID; 

alter table zoo
drop diet_price;
alter table zoo
change diet_table diet_price float;
alter table zoo
add column diet_price float;

select zoo.keeper_name, count(animal_id), sum(diet.diet_price)
from zoo
inner join diet
on zoo.diet_ID = diet.diet_ID
group by keeper_name;

alter table zoo 
add diet_price float;



